<a href="{{ route('home') }}"><img src="{{ asset('frontend/assets/img/logo/logo1.png') }}" alt="rkpdmareting.com"></a>
